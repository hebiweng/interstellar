# Implementation Notes

## Shared AI lifecycle

`AIReportTaskManager` deliberately does not know Ask or Compare astrology schemas.

It owns transport lifecycle only:

```text
submit
  -> optional recover-first (explicit retry only)
  -> create
  -> poll status
  -> fetch

recover
  -> status-if-exists
  -> completed: fetch
  -> failed: terminal relay failure
  -> generating: poll
  -> missing: nil

recover NEVER calls create
```

Domain layers decode and validate fetched bytes before storing.

This keeps three failure classes distinct:

```text
Relay explicit failed
    -> relayFailed

Network / App Attest / HTTP delivery uncertainty
    -> deliveryFailed

Fetched result violates domain contract
    -> domain validation error
    -> no automatic regenerate
```

## Themes

Themes remains independent by request. Its recovery bug was caused by:

```text
persisted generating
 -> load converts to chartsReady
 -> resume -> retry
 -> beginReportGeneration
 -> createTask
```

It is changed to:

```text
persisted generating
 -> remains generating
 -> resume
 -> statusIfExists
 -> wait/fetch only
```

## Wheel

The old `ChartWheelView` mixed geometry, drawing and staged reveal animation. The new implementation keeps `Canvas` but separates configuration concerns:

```text
ChartDisplayMode
  -> ChartDisplayConfig
  -> ChartGeometry
  -> ChartVisualTokens
  -> static ChartWheelView
```

No astrology fact or Swiss Ephemeris calculation is changed.

The Simple / Pro picker exists only on Charts while `viewMode == .wheel`. Other consumers of `ChartWheelView` use the new static renderer with the default Simple density but do not receive the Charts-only Simple summary unless `presentation == .standard`.

## Files modified after apply

Production:

- `ios/App/AppAIReportService.swift`
- `ios/App/AskDeepAnalysis.swift`
- `ios/App/CompareAIService.swift`
- `ios/App/ThemesFeature.swift`
- `ios/App/ChartRenderer.swift`
- `ios/App/ChartsView.swift`

Tests:

- `ios/Tests/CommerceTests.swift`

Explicitly untouched:

- `ios/App/AIGeneration.swift`
- `ios/App/Reports.swift`
- `ios/App/ReportsView.swift`
- astrology calculation packages
- Relay server
- `project.pbxproj`
