# Interstellar R5 AI + Wheel Refactor Overlay

基线：`hebiweng/interstellar` `zip` 分支  
Commit：`661240643dd4a9b45978389d9c7dccfe9965f14c`  
日期：2026-09-02

本交付是针对上述精确源码基线的**可应用修改包**。当前执行环境无法直接 `git clone` GitHub，因此没有重新打包完整仓库；`tools/apply_interstellar_changes.py` 会把本包中的实现安全地应用到完整的 Interstellar checkout。

## 本次范围

### 1. Ask / Compare：统一 AI Report Task 生命周期

新增共享 `AIReportTaskManager`，统一负责：

- `/v1/generate`
- `/v1/reports/status`
- `/v1/reports/fetch`
- 10 秒轮询
- recovery / reconcile
- delivery failure 与 relay terminal failure 分类
- explicit user retry 的恢复优先逻辑

硬约束：

- `recover()` 永远不会调用 `/v1/generate`
- 网络 / App Attest / status / fetch / decode 异常不会自动新建 AI 请求
- 只有正常 `submit()` 或用户显式 retry 才可能调用 `/v1/generate`
- 用户 retry 会先查原 `requestID`
- 只有 Relay 明确 `status == failed` 后，retry 才允许使用同一 `requestID` 重新提交
- completed 但本地 decode / fingerprint / evidence validation 失败时，不会自动再生成
- ACK 仍在 Ask / Compare 各自完成本地原子保存后执行

Ask 与 Compare 保留各自：

- facts builder
- semantic fingerprint
- facts hash
- request schema
- response decoder
- evidence validator
- 本地 Store / UI

### 2. Themes：最小恢复修复

没有迁移到新 AI Manager。

仅修复：

- App 重启后不再把 `generating_report` 改回 `charts_ready`
- 自动 resume 只执行 `status/fetch`，不进入 `createTask`
- 轮询 3 秒改为 10 秒
- cancellation / transport interruption 保留为可恢复的 `generating_report`
- 手动 retry 仍保留原 Theme 生成入口

### 3. Reports

**完全不修改。**

`AIGeneration.swift`、`Reports.swift`、`ReportsView.swift` 均不在 apply 脚本修改目标中。

### 4. Charts Wheel UI

按 `Interstellar_Chart_Wheel_UI_Redesign_Spec.md` 的主要视觉/架构要求实现，并按后续明确要求覆盖两项：

- 删除 Wheel entrance / fade / scale animation
- 不加入 planet / house 点击 selection / highlight

保留 Horary 的确定性 highlighted houses / key aspects，因为这是业务数据 overlay，不是点击交互。

实现：

- `ChartDisplayMode.simple / pro`
- Simple 默认
- 共享 `ChartGeometry`
- 共享 `ChartDisplayConfig`
- 共享 `ChartVisualTokens`
- Dark / Light 共用一套 adaptive tokens
- 响应式 safe bounds
- ASC / DSC / MC / IC 标签向盘内 clamp
- 375 / 390 / 393 / 402 / 430 pt 屏宽测试
- muted planetary colors
- Simple：
  - 大号星座 glyph
  - 稀疏刻度
  - 宫位 / house numbers
  - 轴线
  - 行星 glyph + degree + house
  - 主要相位
  - Sun / Moon / Rising 摘要
- Pro：
  - 密集刻度
  - 分级度数
  - 更多现有相位线
  - metadata
  - Planets / Aspects / Houses / Table
  - planet professional table

说明：当前 AstroCore 只提供 conjunction / sextile / square / trine / opposition 五类 major aspects。本次不改计算核心，所以 Pro 不伪造 minor aspects。

## 为什么不新增 Xcode target 文件

当前 `Interstellar.xcodeproj` 使用显式 `PBXBuildFile` sources，而不是自动 folder synchronization。

因此 apply 时：

- `AIReportTaskManager` 注入现有 `AppAIReportService.swift`
- Wheel architecture 注入现有 `ChartRenderer.swift`
- Pro detail view 注入现有 `ChartsView.swift`
- 新测试追加到现有 `CommerceTests.swift`

这样：

- 不需要 XcodeGen
- 不需要修改 `project.pbxproj`
- 不需要在 Xcode 手工 Add Files to Target

## 应用

在 Mac 上准备当前 `zip` 分支完整 checkout，然后：

```bash
python3 /path/to/this-bundle/tools/apply_interstellar_changes.py /path/to/interstellar
```

脚本首先验证 Git blob SHA，只有精确匹配本交付基线才会修改。

脚本具有事务回滚：任何 marker / contract 不匹配时，会恢复所有已触碰文件。

## Bundle 自检

```bash
python3 tools/verify_interstellar_bundle.py
```

## Mac / Xcode 编译验证

```bash
tools/verify_on_mac.sh /path/to/interstellar
```

当前 ChatGPT 执行环境没有 Xcode，因此这里完成的是：

- Swift parser：通过
- Python apply script compile：通过
- AI lifecycle hard-invariant static verification：通过
- Wheel no-animation/no-selection static verification：通过
- Responsive geometry test source：已加入

最终 iOS typecheck / xcodebuild 必须在 macOS + Xcode 环境执行。
