import CoreGraphics
import XCTest
@testable import Interstellar

final class ChartWheelGeometryTests: XCTestCase {
    func testSimpleGeometryStaysInsideSafeBoundsAcrossPhoneWidths() {
        // ChartsView uses 18pt page padding on each side. These are the
        // resulting content widths for the supported iPhone width classes.
        let screenWidths: [CGFloat] = [375, 390, 393, 402, 430]

        for screenWidth in screenWidths {
            let contentWidth = screenWidth - 36
            let geometry = ChartGeometry(
                size: CGSize(
                    width: contentWidth,
                    height: contentWidth
                ),
                mode: .simple,
                externalLabelReserve: 0
            )

            XCTAssertGreaterThan(geometry.wheelRadius, 0)
            XCTAssertGreaterThanOrEqual(
                geometry.safeLabelBounds.minX,
                8,
                "screen width \(screenWidth)"
            )
            XCTAssertLessThanOrEqual(
                geometry.safeLabelBounds.maxX,
                contentWidth - 8,
                "screen width \(screenWidth)"
            )
            XCTAssertLessThanOrEqual(
                geometry.wheelRadius * 2,
                geometry.safeLabelBounds.width + 0.001,
                "screen width \(screenWidth)"
            )
            XCTAssertLessThan(
                geometry.zodiacRadius,
                geometry.wheelRadius,
                "screen width \(screenWidth)"
            )
            XCTAssertLessThan(
                geometry.outerPlanetRadius,
                geometry.zodiacRadius,
                "screen width \(screenWidth)"
            )
            XCTAssertLessThan(
                geometry.aspectRadius,
                geometry.outerPlanetRadius,
                "screen width \(screenWidth)"
            )
        }
    }

    func testAxisLabelClampNeverLeavesSafeBounds() {
        let geometry = ChartGeometry(
            size: CGSize(width: 339, height: 339),
            mode: .simple,
            externalLabelReserve: 0
        )

        for longitude in stride(
            from: 0.0,
            to: 360.0,
            by: 5.0
        ) {
            let point = geometry.clampedLabelPoint(
                longitude: longitude,
                rotation: 127.5,
                radius: geometry.wheelRadius - 6,
                horizontalReserve: 17,
                verticalReserve: 9
            )

            XCTAssertGreaterThanOrEqual(
                point.x,
                geometry.safeLabelBounds.minX + 17 - 0.001
            )
            XCTAssertLessThanOrEqual(
                point.x,
                geometry.safeLabelBounds.maxX - 17 + 0.001
            )
            XCTAssertGreaterThanOrEqual(
                point.y,
                geometry.safeLabelBounds.minY + 9 - 0.001
            )
            XCTAssertLessThanOrEqual(
                point.y,
                geometry.safeLabelBounds.maxY - 9 + 0.001
            )
        }
    }

    func testSimpleAndProShareSameGeometryTypeWithDifferentDensity() {
        let size = CGSize(width: 339, height: 339)
        let simple = ChartGeometry(
            size: size,
            mode: .simple,
            externalLabelReserve: 0
        )
        let pro = ChartGeometry(
            size: size,
            mode: .pro,
            externalLabelReserve: 0
        )

        XCTAssertEqual(simple.center, pro.center)
        XCTAssertEqual(simple.wheelRadius, pro.wheelRadius)
        XCTAssertNotEqual(
            simple.outerPlanetRadius,
            pro.outerPlanetRadius
        )

        XCTAssertTrue(ChartDisplayConfig.simple.showSummary)
        XCTAssertFalse(ChartDisplayConfig.pro.showSummary)
        XCTAssertFalse(ChartDisplayConfig.simple.showPlanetTable)
        XCTAssertTrue(ChartDisplayConfig.pro.showPlanetTable)
    }
}
