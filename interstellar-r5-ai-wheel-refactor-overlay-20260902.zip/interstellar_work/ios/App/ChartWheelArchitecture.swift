import AstroCore
import SwiftUI

enum ChartDisplayMode: String, CaseIterable, Identifiable, Sendable {
    case simple
    case pro

    var id: String { rawValue }
}

enum ZodiacLabelDensity: Sendable {
    case glyphOnly
    case glyphAndDegree
}

enum DegreePrecision: Sendable {
    case whole
    case minute
}

enum AspectDensity: Sendable {
    case major
    case extended
}

struct ChartDisplayConfig: Sendable {
    let mode: ChartDisplayMode
    let showMinorAspects: Bool
    let showFullDegreePrecision: Bool
    let showPlanetTable: Bool
    let showChartMetadata: Bool
    let showSummary: Bool
    let zodiacLabelDensity: ZodiacLabelDensity
    let degreePrecision: DegreePrecision
    let aspectDensity: AspectDensity

    static let simple = ChartDisplayConfig(
        mode: .simple,
        showMinorAspects: false,
        showFullDegreePrecision: false,
        showPlanetTable: false,
        showChartMetadata: false,
        showSummary: true,
        zodiacLabelDensity: .glyphOnly,
        degreePrecision: .whole,
        aspectDensity: .major
    )

    static let pro = ChartDisplayConfig(
        mode: .pro,
        // AstroCore currently emits the five major aspect kinds only.
        // Keep the UI honest instead of inventing minor aspects.
        showMinorAspects: false,
        showFullDegreePrecision: true,
        showPlanetTable: true,
        showChartMetadata: true,
        showSummary: false,
        zodiacLabelDensity: .glyphAndDegree,
        degreePrecision: .minute,
        aspectDensity: .extended
    )

    static func config(for mode: ChartDisplayMode) -> ChartDisplayConfig {
        switch mode {
        case .simple: .simple
        case .pro: .pro
        }
    }
}

struct ChartVisualTokens {
    let background: Color
    let wheelSurface: Color
    let primaryText: Color
    let secondaryText: Color
    let gridStrong: Color
    let gridNormal: Color
    let gridWeak: Color
    let axisColor: Color
    let accentColor: Color
    let aspectPositive: Color
    let aspectChallenging: Color
    let aspectNeutral: Color

    static var adaptive: ChartVisualTokens {
        ChartVisualTokens(
            background: AppTheme.background,
            wheelSurface: AppTheme.panel,
            primaryText: AppTheme.text,
            secondaryText: AppTheme.muted,
            gridStrong: AppTheme.text.opacity(0.34),
            gridNormal: AppTheme.text.opacity(0.16),
            gridWeak: AppTheme.text.opacity(0.085),
            axisColor: AppTheme.violet,
            accentColor: AppTheme.violet,
            aspectPositive: AppTheme.blue,
            aspectChallenging: AppTheme.coral,
            aspectNeutral: AppTheme.amber
        )
    }

    func planetColor(_ body: CelestialBody) -> Color {
        switch body {
        case .sun: AppTheme.amber
        case .moon: AppTheme.blue
        case .mercury: AppTheme.violet
        case .venus: AppTheme.mint
        case .mars: AppTheme.coral
        case .jupiter: AppTheme.amber
        case .saturn: AppTheme.muted
        case .uranus: AppTheme.blue
        case .neptune: AppTheme.mint
        case .pluto: AppTheme.violet
        case .trueNode, .lilith, .partOfFortune, .juno:
            AppTheme.muted
        }
    }

    func aspectColor(_ kind: AspectKind) -> Color {
        switch kind {
        case .trine, .sextile:
            aspectPositive
        case .square, .opposition:
            aspectChallenging
        case .conjunction:
            aspectNeutral
        }
    }
}

struct ChartGeometry {
    let bounds: CGRect
    let safeLabelBounds: CGRect
    let center: CGPoint
    let wheelRadius: CGFloat
    let outerTickRadius: CGFloat
    let zodiacRadius: CGFloat
    let outerPlanetRadius: CGFloat
    let innerPlanetRadius: CGFloat
    let houseOuterRadius: CGFloat
    let houseInnerRadius: CGFloat
    let houseNumberRadius: CGFloat
    let aspectRadius: CGFloat
    let comparisonOuterAspectRadius: CGFloat
    let comparisonInnerAspectRadius: CGFloat

    init(
        size: CGSize,
        mode: ChartDisplayMode,
        externalLabelReserve: CGFloat = 12
    ) {
        let bounds = CGRect(origin: .zero, size: size)
        self.bounds = bounds

        // All visible content, including ASC/DSC/MC/IC labels, must stay inside
        // this area. The renderer does not use clipping to hide overflow.
        let edgeInset: CGFloat = 8
        let safe = bounds.insetBy(
            dx: edgeInset + externalLabelReserve,
            dy: edgeInset
        )
        safeLabelBounds = safe

        let diameter = min(safe.width, safe.height)
        let radius = max(1, diameter / 2)
        center = CGPoint(x: bounds.midX, y: bounds.midY)
        wheelRadius = radius

        switch mode {
        case .simple:
            outerTickRadius = radius
            zodiacRadius = radius * 0.90
            outerPlanetRadius = radius * 0.69
            innerPlanetRadius = radius * 0.50
            houseOuterRadius = radius * 0.80
            houseInnerRadius = radius * 0.59
            houseNumberRadius = radius * 0.625
            aspectRadius = radius * 0.555
            comparisonOuterAspectRadius = radius * 0.61
            comparisonInnerAspectRadius = radius * 0.47

        case .pro:
            outerTickRadius = radius
            zodiacRadius = radius * 0.89
            outerPlanetRadius = radius * 0.70
            innerPlanetRadius = radius * 0.51
            houseOuterRadius = radius * 0.81
            houseInnerRadius = radius * 0.595
            houseNumberRadius = radius * 0.625
            aspectRadius = radius * 0.56
            comparisonOuterAspectRadius = radius * 0.615
            comparisonInnerAspectRadius = radius * 0.475
        }
    }

    func point(
        longitude: Double,
        rotation: Double,
        radius: CGFloat
    ) -> CGPoint {
        AstrologyWheelGeometry.point(
            center: center,
            radius: Double(radius),
            longitude: longitude,
            ascendantRotation: rotation
        )
    }

    func clampedLabelPoint(
        longitude: Double,
        rotation: Double,
        radius: CGFloat,
        horizontalReserve: CGFloat = 18,
        verticalReserve: CGFloat = 10
    ) -> CGPoint {
        let raw = point(
            longitude: longitude,
            rotation: rotation,
            radius: radius
        )
        return CGPoint(
            x: min(
                safeLabelBounds.maxX - horizontalReserve,
                max(safeLabelBounds.minX + horizontalReserve, raw.x)
            ),
            y: min(
                safeLabelBounds.maxY - verticalReserve,
                max(safeLabelBounds.minY + verticalReserve, raw.y)
            )
        )
    }
}

struct ChartSummaryItem: Identifiable, Sendable {
    let id: String
    let glyph: String
    let title: String
    let primary: String
    let secondary: String
}


enum ChartWheelCopyKey {
    case simple
    case pro
    case planets
    case aspects
    case houses
    case table
    case sign
    case degree
    case house
    case retro
    case speed
}

enum ChartWheelCopy {
    static func text(
        _ key: ChartWheelCopyKey,
        language: AppLanguage
    ) -> String {
        let code = language.rawValue.lowercased()
        switch code {
        case let value where value.hasPrefix("zh"):
            return chinese(key)
        case let value where value.hasPrefix("es"):
            return spanish(key)
        case let value where value.hasPrefix("fr"):
            return french(key)
        case let value where value.hasPrefix("tr"):
            return turkish(key)
        case let value where value.hasPrefix("de"):
            return german(key)
        case let value where value.hasPrefix("it"):
            return italian(key)
        case let value where value.hasPrefix("ko"):
            return korean(key)
        case let value where value.hasPrefix("pt"):
            return portuguese(key)
        default:
            return english(key)
        }
    }

    private static func english(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "Simple"
        case .pro: "Pro"
        case .planets: "Planets"
        case .aspects: "Aspects"
        case .houses: "Houses"
        case .table: "Table"
        case .sign: "Sign"
        case .degree: "Degree"
        case .house: "House"
        case .retro: "Retro"
        case .speed: "Speed"
        }
    }

    private static func chinese(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "简洁"
        case .pro: "专业"
        case .planets: "行星"
        case .aspects: "相位"
        case .houses: "宫位"
        case .table: "表格"
        case .sign: "星座"
        case .degree: "度数"
        case .house: "宫位"
        case .retro: "逆行"
        case .speed: "速度"
        }
    }

    private static func spanish(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "Simple"
        case .pro: "Pro"
        case .planets: "Planetas"
        case .aspects: "Aspectos"
        case .houses: "Casas"
        case .table: "Tabla"
        case .sign: "Signo"
        case .degree: "Grado"
        case .house: "Casa"
        case .retro: "Retró."
        case .speed: "Velocidad"
        }
    }

    private static func french(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "Simple"
        case .pro: "Pro"
        case .planets: "Planètes"
        case .aspects: "Aspects"
        case .houses: "Maisons"
        case .table: "Tableau"
        case .sign: "Signe"
        case .degree: "Degré"
        case .house: "Maison"
        case .retro: "Rétro."
        case .speed: "Vitesse"
        }
    }

    private static func turkish(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "Basit"
        case .pro: "Pro"
        case .planets: "Gezegenler"
        case .aspects: "Açılar"
        case .houses: "Evler"
        case .table: "Tablo"
        case .sign: "Burç"
        case .degree: "Derece"
        case .house: "Ev"
        case .retro: "Retro"
        case .speed: "Hız"
        }
    }

    private static func german(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "Einfach"
        case .pro: "Pro"
        case .planets: "Planeten"
        case .aspects: "Aspekte"
        case .houses: "Häuser"
        case .table: "Tabelle"
        case .sign: "Zeichen"
        case .degree: "Grad"
        case .house: "Haus"
        case .retro: "Retro"
        case .speed: "Tempo"
        }
    }

    private static func italian(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "Semplice"
        case .pro: "Pro"
        case .planets: "Pianeti"
        case .aspects: "Aspetti"
        case .houses: "Case"
        case .table: "Tabella"
        case .sign: "Segno"
        case .degree: "Grado"
        case .house: "Casa"
        case .retro: "Retro"
        case .speed: "Velocità"
        }
    }

    private static func korean(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "간단"
        case .pro: "프로"
        case .planets: "행성"
        case .aspects: "애스펙트"
        case .houses: "하우스"
        case .table: "표"
        case .sign: "사인"
        case .degree: "도수"
        case .house: "하우스"
        case .retro: "역행"
        case .speed: "속도"
        }
    }

    private static func portuguese(_ key: ChartWheelCopyKey) -> String {
        switch key {
        case .simple: "Simples"
        case .pro: "Pro"
        case .planets: "Planetas"
        case .aspects: "Aspectos"
        case .houses: "Casas"
        case .table: "Tabela"
        case .sign: "Signo"
        case .degree: "Grau"
        case .house: "Casa"
        case .retro: "Retró."
        case .speed: "Velocidade"
        }
    }
}
