#!/bin/bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "usage: verify_on_mac.sh /path/to/interstellar" >&2
  exit 2
fi

REPO="$(cd "$1" && pwd)"
IOS="$REPO/ios"

if [ ! -d "$IOS/Interstellar.xcodeproj" ]; then
  echo "Interstellar.xcodeproj not found under $IOS" >&2
  exit 2
fi

echo "== Swift source contract checks =="
grep -q "struct AIReportTaskManager" "$IOS/App/AppAIReportService.swift"
grep -q "AIReportTaskManager()" "$IOS/App/AskDeepAnalysis.swift"
grep -q "AIReportTaskManager()" "$IOS/App/CompareAIService.swift"
grep -q "ChartDisplayMode" "$IOS/App/ChartRenderer.swift"
grep -q "ChartProDetailView" "$IOS/App/ChartsView.swift"

if grep -q "revealProgress" "$IOS/App/ChartRenderer.swift"; then
  echo "Old wheel reveal animation still present" >&2
  exit 1
fi

echo "== Xcode Debug build =="
cd "$IOS"
xcodebuild \
  -project Interstellar.xcodeproj \
  -scheme Interstellar \
  -configuration Debug \
  -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO \
  SWIFT_TREAT_WARNINGS_AS_ERRORS=YES \
  build

echo "== Unit-test build =="
xcodebuild \
  -project Interstellar.xcodeproj \
  -scheme Interstellar \
  -configuration Debug \
  -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO \
  SWIFT_TREAT_WARNINGS_AS_ERRORS=YES \
  build-for-testing

echo "MAC VERIFICATION PASSED"
