#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def fail(message: str) -> None:
    raise AssertionError(message)

def between(text: str, start: str, end: str) -> str:
    i = text.find(start)
    if i < 0:
        fail(f"missing start marker: {start}")
    j = text.find(end, i)
    if j < 0:
        fail(f"missing end marker: {end}")
    return text[i:j]

def parse_swift(path: Path) -> None:
    swiftc = shutil.which("swiftc")
    if not swiftc:
        print(f"SKIP swift parser: {path.name} (swiftc unavailable)")
        return
    subprocess.run(
        [swiftc, "-frontend", "-parse", str(path)],
        check=True,
        stdout=subprocess.DEVNULL,
    )
    print(f"PASS swift parser: {path.relative_to(ROOT)}")

def main() -> None:
    manager_path = ROOT / "ios" / "App" / "AIReportTaskManager.swift"
    manager = manager_path.read_text(encoding="utf-8")

    recover = between(
        manager,
        "    func recover<Result>(",
        "    private func waitForResult<Result>(",
    )
    if "createTask" in recover:
        fail("AIReportTaskManager.recover contains createTask")
    if 'path: "v1/generate"' not in manager:
        fail("shared client has no generate endpoint")
    if manager.count("_ = try await client.createTask") != 1:
        fail("shared manager must have exactly one createTask call site")
    if "alreadyNotifiedGenerating: true" not in manager:
        fail("generating recovery notification is not single-flight")
    print("PASS AI manager recovery/create invariant")

    compare = (
        ROOT / "ios" / "App" / "CompareAIService.swift"
    ).read_text(encoding="utf-8")
    if "CompareRelayClient" in compare:
        fail("Compare still contains duplicate Relay client")
    if "AIReportTaskManager()" not in compare:
        fail("Compare is not migrated to shared manager")
    if "waitForResult(" in compare:
        fail("Compare still contains its own polling loop")
    print("PASS Compare migration")

    ask = (
        ROOT / "patches" / "AskDeepAnalysis.service-replacement.swiftfrag"
    ).read_text(encoding="utf-8")
    if "AskDeepRelayClient" in ask:
        fail("Ask replacement still contains duplicate Relay client")
    if "AIReportTaskManager()" not in ask:
        fail("Ask replacement is not migrated to shared manager")
    if "waitForResult(" in ask:
        fail("Ask replacement still contains its own polling loop")
    print("PASS Ask migration")

    theme_relay = (
        ROOT / "patches" / "ThemesFeature.relay-replacement.swiftfrag"
    ).read_text(encoding="utf-8")
    theme_manager = (
        ROOT / "patches" / "ThemesFeature.manager-recovery.swiftfrag"
    ).read_text(encoding="utf-8")
    if "3_000_000_000" in theme_relay:
        fail("Theme still polls every 3 seconds")
    if "10_000_000_000" not in theme_relay:
        fail("Theme 10-second polling missing")
    resume = between(
        theme_manager,
        "    func resumePendingReport(",
        "    private func beginReportGeneration",
    ) if "    private func beginReportGeneration" in theme_manager else theme_manager[
        theme_manager.find("    func resumePendingReport("):
    ]
    if "reportService.generate" in resume or "beginReportGeneration(" in resume:
        fail("Theme automatic resume can enter generation")
    if "reportService.recover" not in resume:
        fail("Theme automatic resume does not recover")
    print("PASS Theme minimal recovery fix")

    wheel = (
        ROOT / "patches" / "ChartRenderer.ChartWheelView-replacement.swiftfrag"
    ).read_text(encoding="utf-8")
    forbidden_wheel_tokens = [
        "revealProgress",
        "accessibilityReduceMotion",
        ".scaleEffect(",
        "withAnimation(",
        ".animation(",
        ".onTapGesture",
        "TapGesture(",
        "DragGesture(",
        "selectedPlanet",
        "selectedHouse",
    ]
    found = [token for token in forbidden_wheel_tokens if token in wheel]
    if found:
        fail("wheel contains removed animation/selection tokens: " + ", ".join(found))
    if "ChartGeometry(" not in wheel:
        fail("wheel does not use shared ChartGeometry")
    if "displayMode: ChartDisplayMode = .simple" not in wheel:
        fail("Simple is not the default wheel display mode")
    print("PASS static wheel invariant")

    architecture = (
        ROOT / "ios" / "App" / "ChartWheelArchitecture.swift"
    ).read_text(encoding="utf-8")
    for width in ("375", "390", "393", "402", "430"):
        # Widths live in tests, not architecture. Checked below.
        pass
    if "ChartDisplayConfig" not in architecture:
        fail("display config missing")
    if "ChartVisualTokens" not in architecture:
        fail("visual tokens missing")
    if "ChartGeometry" not in architecture:
        fail("geometry missing")
    print("PASS wheel architecture")

    geometry_tests = (
        ROOT / "ios" / "Tests" / "ChartWheelGeometryTests.swift"
    ).read_text(encoding="utf-8")
    for width in ("375", "390", "393", "402", "430"):
        if width not in geometry_tests:
            fail(f"missing responsive width test: {width}")
    print("PASS responsive width coverage")

    apply_script = (
        ROOT / "tools" / "apply_interstellar_changes.py"
    ).read_text(encoding="utf-8")
    if '"AIGeneration.swift"' in apply_script:
        fail("Reports/AIGeneration.swift is targeted by apply script")
    if "Reports.swift" in apply_script or "ReportsView.swift" in apply_script:
        fail("Reports source is targeted by apply script")
    if "verify_baseline(app)" not in apply_script:
        fail("baseline source guard missing")
    if "rollback_on_failure" not in apply_script:
        fail("transaction rollback missing")
    if "Interstellar.xcodeproj" in apply_script or "project.pbxproj" in apply_script:
        fail("apply script unexpectedly edits Xcode project")
    print("PASS Reports untouched / no project-file edits")

    apply_source = (
        ROOT / "tools" / "apply_interstellar_changes.py"
    ).read_text(encoding="utf-8")
    compile(
        apply_source,
        str(ROOT / "tools" / "apply_interstellar_changes.py"),
        "exec",
    )
    print("PASS apply script Python compile")

    swift_files = [
        ROOT / "ios" / "App" / "AIReportTaskManager.swift",
        ROOT / "ios" / "App" / "ChartWheelArchitecture.swift",
        ROOT / "ios" / "App" / "ChartProDetailView.swift",
        ROOT / "ios" / "App" / "CompareAIService.swift",
        ROOT / "ios" / "Tests" / "AIReportTaskManagerTests.swift",
        ROOT / "ios" / "Tests" / "ChartWheelGeometryTests.swift",
        ROOT / "patches" / "AskDeepAnalysis.service-replacement.swiftfrag",
        ROOT / "patches" / "ChartRenderer.ChartWheelView-replacement.swiftfrag",
        ROOT / "patches" / "ChartsView.control-replacement.swiftfrag",
        ROOT / "patches" / "ThemesFeature.manager-recovery.swiftfrag",
        ROOT / "patches" / "ThemesFeature.relay-replacement.swiftfrag",
    ]
    for path in swift_files:
        parse_swift(path)

    print("\nBUNDLE VERIFICATION PASSED")

if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"BUNDLE VERIFICATION FAILED: {error}", file=sys.stderr)
        raise
