#!/usr/bin/env python3
from pathlib import Path
import atexit
import hashlib
import shutil
import sys
import tempfile


def git_blob_sha(path: Path) -> str:
    data = path.read_bytes()
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()

def verify_baseline(app: Path) -> None:
    expected = {
        "AskDeepAnalysis.swift": "9c660cda636a66ab4299b04845b9d89a19174e45",
        "CompareAIService.swift": "cf134999d02f5a32214abeb0a8f3238fa05dd0c9",
        "ChartRenderer.swift": "760e7ef0266ead1e49647d8be5237d12ed577683",
        "ChartsView.swift": "c58d61dec7fc8dc6eeb44ca4a5bdaf64554a24da",
        "ThemesFeature.swift": "2b87ffb66c2b62f9c83f04632fb9a0820326c830",
        "AppAIReportService.swift": "f960e01f27d55208413b21c8a4153dd293eb3176",
    }
    mismatches = []
    for name, sha in expected.items():
        path = app / name
        if not path.exists():
            mismatches.append(f"{name}: missing")
            continue
        actual = git_blob_sha(path)
        if actual != sha:
            mismatches.append(f"{name}: expected {sha}, got {actual}")
    if mismatches:
        detail = "\n  ".join(mismatches)
        raise RuntimeError(
            "Source baseline does not match Interstellar zip@"
            "661240643dd4a9b45978389d9c7dccfe9965f14c.\n  "
            + detail
        )

def replace_between(text: str, start: str, end: str, replacement: str) -> str:
    i = text.find(start)
    if i < 0:
        raise RuntimeError(f"start marker not found: {start}")
    j = text.find(end, i)
    if j < 0:
        raise RuntimeError(f"end marker not found: {end}")
    return text[:i] + replacement + text[j:]

def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: apply_interstellar_changes.py /path/to/interstellar")
    repo = Path(sys.argv[1]).resolve()
    bundle = Path(__file__).resolve().parents[1]

    app = repo / "ios" / "App"
    if not app.exists():
        raise RuntimeError(f"not an Interstellar checkout: {repo}")

    # This bundle is intentionally pinned to the source that was published on
    # the zip branch. Refuse to perform textual replacements on a different
    # source revision.
    verify_baseline(app)
    commerce_tests = repo / "ios" / "Tests" / "CommerceTests.swift"
    commerce_expected = "405be0ca3421b99f94a2d5b021f52f30ef50cc5c"
    if not commerce_tests.exists():
        raise RuntimeError("CommerceTests.swift: missing")
    commerce_actual = git_blob_sha(commerce_tests)
    if commerce_actual != commerce_expected:
        raise RuntimeError(
            "CommerceTests.swift baseline mismatch: expected "
            + commerce_expected
            + ", got "
            + commerce_actual
        )

    # Transactional safety: restore every touched source if any later textual
    # contract fails. A successful run removes the temporary backup.
    touched_paths = [
        app / "AppAIReportService.swift",
        app / "CompareAIService.swift",
        app / "AskDeepAnalysis.swift",
        app / "ThemesFeature.swift",
        app / "ChartRenderer.swift",
        app / "ChartsView.swift",
        commerce_tests,
    ]
    backup_root = Path(
        tempfile.mkdtemp(prefix="interstellar-ai-wheel-backup-")
    )
    for source in touched_paths:
        relative = source.relative_to(repo)
        destination = backup_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)

    transaction = {"committed": False}

    def rollback_on_failure() -> None:
        if transaction["committed"]:
            return
        for source in touched_paths:
            relative = source.relative_to(repo)
            backup = backup_root / relative
            if backup.exists():
                shutil.copy2(backup, source)
        shutil.rmtree(backup_root, ignore_errors=True)

    atexit.register(rollback_on_failure)

    # Shared AI lifecycle infrastructure is injected into an existing AI
    # source file so the checked-in Xcode project needs no new PBX file entry.
    ai_host_path = app / "AppAIReportService.swift"
    ai_host = ai_host_path.read_text(encoding="utf-8")
    ai_manager = (
        bundle / "ios" / "App" / "AIReportTaskManager.swift"
    ).read_text(encoding="utf-8")
    ai_manager = ai_manager.replace("import Foundation\n\n", "", 1)
    ai_host = ai_host.rstrip() + "\n\n// MARK: - Shared AI Report Task Lifecycle\n\n" + ai_manager + "\n"
    ai_host_path.write_text(ai_host, encoding="utf-8")

    # Compare service is deliberately replaced as a whole. Domain facts and
    # validation stay in the file; duplicated Relay lifecycle code is removed.
    shutil.copy2(
        bundle / "ios" / "App" / "CompareAIService.swift",
        app / "CompareAIService.swift"
    )

    # Ask is a large feature file. Replace only its Relay client/service region;
    # facts, persistence, manager and UI remain untouched.
    ask_path = app / "AskDeepAnalysis.swift"
    ask = ask_path.read_text(encoding="utf-8")
    replacement = (
        bundle / "patches" / "AskDeepAnalysis.service-replacement.swiftfrag"
    ).read_text(encoding="utf-8")
    ask = replace_between(
        ask,
        "private struct AskDeepRelayClient: Sendable {",
        "enum AskDeepRecordStatus: String, Codable {",
        replacement
    )
    ask_path.write_text(ask, encoding="utf-8")


    # Themes: keep its domain service, but fix recovery semantics with the
    # smallest possible change. Auto-resume never generates, and polling is 10s.
    themes_path = app / "ThemesFeature.swift"
    themes = themes_path.read_text(encoding="utf-8")

    # Preserve generating_report across process death. The old code converted
    # it to charts_ready and then re-entered the generation path.
    old_load = """        for index in decoded.indices where decoded[index].status == .generatingReport {
            // The in-memory polling task is gone after process termination, but
            // Relay may still be generating the report. Keep the persisted
            // analysis pending so the result screen can resume polling with the
            // same idempotency key.
            decoded[index].status = .chartsReady
            decoded[index].generationError = nil
        }
"""
    if old_load not in themes:
        raise RuntimeError("Themes persisted-generating migration block not found")
    themes = themes.replace(old_load, "", 1)
    themes = themes.replace(
        "              var decoded = try? JSONDecoder().decode([ThemeAnalysis].self, from: data)\n",
        "              let decoded = try? JSONDecoder().decode([ThemeAnalysis].self, from: data)\n",
        1
    )

    relay_replacement = (
        bundle / "patches" / "ThemesFeature.relay-replacement.swiftfrag"
    ).read_text(encoding="utf-8")
    themes = replace_between(
        themes,
        "struct ThemeRelayClient: Sendable {",
        "@MainActor\nfinal class ThemeAnalysisManager: ObservableObject {",
        relay_replacement
    )

    manager_replacement = (
        bundle / "patches" / "ThemesFeature.manager-recovery.swiftfrag"
    ).read_text(encoding="utf-8")
    themes = replace_between(
        themes,
        "    func retry(analysisID: String, model: AppModel) {",
        "    private func beginReportGeneration(analysisID: String, model: AppModel) {",
        manager_replacement
    )

    # Once a request has entered the generation path, cancellation or transport
    # interruption must leave it recoverable instead of resetting it to
    # charts_ready (which historically re-entered createTask on resume).
    old_cancel = """            } catch is CancellationError {
                // Suspension or termination does not mean Relay failed. Keep
                // the request pending and resume it with the original key.
                if var current = self.store.analysis(id: analysisID) {
                    current.status = .chartsReady
                    current.generationError = nil
                    self.store.upsert(current)
                }
            } catch is URLError {
                if var current = self.store.analysis(id: analysisID) {
                    current.status = .chartsReady
                    current.generationError = nil
                    self.store.upsert(current)
                }
"""
    new_cancel = """            } catch is CancellationError {
                if var current = self.store.analysis(id: analysisID) {
                    current.status = .generatingReport
                    current.generationError = nil
                    self.store.upsert(current)
                }
            } catch is URLError {
                if var current = self.store.analysis(id: analysisID) {
                    current.status = .generatingReport
                    current.generationError = nil
                    self.store.upsert(current)
                }
"""
    if old_cancel not in themes:
        raise RuntimeError("Themes cancellation block no longer matches expected R5 source")
    themes = themes.replace(old_cancel, new_cancel)
    themes_path.write_text(themes, encoding="utf-8")


    # Wheel renderer: inject shared display/geometry types into the existing
    # renderer file, then replace only ChartWheelView. AspectChartView and the
    # rest of ChartRenderer.swift stay unchanged.
    renderer_path = app / "ChartRenderer.swift"
    renderer = renderer_path.read_text(encoding="utf-8")
    wheel_architecture = (
        bundle / "ios" / "App" / "ChartWheelArchitecture.swift"
    ).read_text(encoding="utf-8")
    wheel_architecture = wheel_architecture.replace(
        "import AstroCore\nimport SwiftUI\n\n",
        "",
        1
    )
    renderer = renderer.replace(
        "struct ChartWheelView: View {",
        "// MARK: - Wheel Display Architecture\n\n"
        + wheel_architecture
        + "\n\nstruct ChartWheelView: View {",
        1
    )
    wheel_replacement = (
        bundle / "patches" / "ChartRenderer.ChartWheelView-replacement.swiftfrag"
    ).read_text(encoding="utf-8")
    renderer = replace_between(
        renderer,
        "struct ChartWheelView: View {",
        "struct AspectChartView: View {",
        wheel_replacement
    )
    renderer_path.write_text(renderer, encoding="utf-8")

    # Charts page: persist the Simple/Pro choice locally and expose the switch
    # only while viewing the wheel.
    charts_path = app / "ChartsView.swift"
    charts = charts_path.read_text(encoding="utf-8")

    state_marker = "    @State private var chartsSpace: ChartsSpace = .you\n"
    if state_marker not in charts:
        raise RuntimeError("ChartsView state marker not found")
    charts = charts.replace(
        state_marker,
        state_marker
        + '    @AppStorage("charts.wheel-display-mode") '
        + 'private var wheelDisplayModeRaw = ChartDisplayMode.simple.rawValue\n',
        1
    )

    control_replacement = (
        bundle / "patches" / "ChartsView.control-replacement.swiftfrag"
    ).read_text(encoding="utf-8")
    charts = replace_between(
        charts,
        "    private var chartControlBar: some View {",
        "    private var synastryPeopleSelector: some View {",
        control_replacement
    )

    # Insert a typed binding without depending on AppStorage RawRepresentable
    # overloads, which keeps this stable under Swift 6.
    selector_marker = "    private var viewSelector: some View {\n"
    binding = """    private var wheelDisplayMode: ChartDisplayMode {
        ChartDisplayMode(rawValue: wheelDisplayModeRaw) ?? .simple
    }

    private var wheelDisplayModeBinding: Binding<ChartDisplayMode> {
        Binding(
            get: { wheelDisplayMode },
            set: { wheelDisplayModeRaw = $0.rawValue }
        )
    }

"""
    if selector_marker not in charts:
        raise RuntimeError("ChartsView viewSelector marker not found")
    charts = charts.replace(selector_marker, binding + selector_marker, 1)

    old_single = """                ChartWheelView(
                    snapshot: snapshot,
                    reference: model.referenceSnapshot(for: model.selectedChart),
                    comparisonAspects: model.selectedChart.usesReferenceWheel
                        ? model.comparisonAspects(for: model.selectedChart)
                        : [],
                    language: model.language
                )
                .padding(12)
                .background(AppTheme.panel, in: RoundedRectangle(cornerRadius: 24))
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(AppTheme.line))
"""
    new_single = """                let reference = model.referenceSnapshot(
                    for: model.selectedChart
                )
                let aspects = model.selectedChart.usesReferenceWheel
                    ? model.comparisonAspects(for: model.selectedChart)
                    : []

                ChartWheelView(
                    snapshot: snapshot,
                    reference: reference,
                    comparisonAspects: aspects,
                    language: model.language,
                    displayMode: wheelDisplayMode
                )
                .padding(.vertical, 8)
                .background(
                    AppTheme.panel,
                    in: RoundedRectangle(cornerRadius: 24)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 24)
                        .stroke(AppTheme.line)
                )

                if wheelDisplayMode == .pro {
                    ChartProDetailView(
                        snapshot: snapshot,
                        reference: reference,
                        comparisonAspects: aspects,
                        language: model.language
                    )
                }
"""
    if old_single not in charts:
        raise RuntimeError("ChartsView single-wheel block no longer matches expected source")
    charts = charts.replace(old_single, new_single, 1)

    old_relationship = """                ChartWheelView(
                    snapshot: artifact.snapshot,
                    reference: artifact.reference,
                    comparisonAspects: artifact.reference == nil ? [] : artifact.comparisonAspects,
                    language: model.language
                )
                .padding(12)
                .background(AppTheme.panel, in: RoundedRectangle(cornerRadius: 24))
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(AppTheme.line))
"""
    new_relationship = """                let aspects = artifact.reference == nil
                    ? []
                    : artifact.comparisonAspects

                ChartWheelView(
                    snapshot: artifact.snapshot,
                    reference: artifact.reference,
                    comparisonAspects: aspects,
                    language: model.language,
                    displayMode: wheelDisplayMode
                )
                .padding(.vertical, 8)
                .background(
                    AppTheme.panel,
                    in: RoundedRectangle(cornerRadius: 24)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 24)
                        .stroke(AppTheme.line)
                )

                if wheelDisplayMode == .pro {
                    ChartProDetailView(
                        snapshot: artifact.snapshot,
                        reference: artifact.reference,
                        comparisonAspects: aspects,
                        language: model.language
                    )
                }
"""
    if old_relationship not in charts:
        raise RuntimeError("ChartsView relationship-wheel block no longer matches expected source")
    charts = charts.replace(old_relationship, new_relationship, 1)
    pro_detail = (
        bundle / "ios" / "App" / "ChartProDetailView.swift"
    ).read_text(encoding="utf-8")
    pro_detail = pro_detail.replace(
        "import AstroCore\nimport Foundation\nimport SwiftUI\n\n",
        "",
        1
    )
    pro_marker = "private struct ReportGeneratingSheet: View {"
    if pro_marker not in charts:
        raise RuntimeError("ChartsView ReportGeneratingSheet marker not found")
    charts = charts.replace(
        pro_marker,
        "// MARK: - Pro Wheel Details\n\n"
        + pro_detail
        + "\n\n"
        + pro_marker,
        1
    )
    charts_path.write_text(charts, encoding="utf-8")

    # Tests are appended to an existing test source for the same reason: no
    # project regeneration and no PBXBuildFile edits are required.
    commerce_tests_path = repo / "ios" / "Tests" / "CommerceTests.swift"
    commerce_tests = commerce_tests_path.read_text(encoding="utf-8")
    if "import CoreGraphics\n" not in commerce_tests:
        commerce_tests = commerce_tests.replace(
            "import XCTest\n",
            "import XCTest\nimport CoreGraphics\n",
            1
        )

    for name, marker in (
        ("AIReportTaskManagerTests.swift", "@MainActor\nfinal class AIReportTaskManagerTests"),
        ("ChartWheelGeometryTests.swift", "final class ChartWheelGeometryTests"),
    ):
        fragment = (bundle / "ios" / "Tests" / name).read_text(encoding="utf-8")
        if name == "AIReportTaskManagerTests.swift":
            fragment = fragment.replace(
                "import Foundation\nimport XCTest\n@testable import Interstellar\n\n",
                "",
                1
            )
        else:
            fragment = fragment.replace(
                "import CoreGraphics\nimport XCTest\n@testable import Interstellar\n\n",
                "",
                1
            )
        if marker in commerce_tests:
            raise RuntimeError(f"{name} appears to be already applied")
        commerce_tests = commerce_tests.rstrip() + "\n\n" + fragment + "\n"

    commerce_tests_path.write_text(commerce_tests, encoding="utf-8")

    transaction["committed"] = True
    shutil.rmtree(backup_root, ignore_errors=True)
    print("Applied AI manager, Ask/Compare, Theme recovery, and wheel UI refactor.")

if __name__ == "__main__":
    main()
